package GeneralDef;

public enum Owner {
	PLAYER_1, PLAYER_2, NONE;
}
