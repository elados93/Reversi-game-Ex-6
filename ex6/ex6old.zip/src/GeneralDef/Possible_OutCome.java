package GeneralDef;

public enum Possible_OutCome {
	SUCCESS, OUT_OF_BOUND, OCCUPIED_CELL, ILLEGAL_MOVE;
}
