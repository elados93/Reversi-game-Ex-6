package GeneralDef;

public enum Status {
	WIN, DRAW, RUNNING;
}
